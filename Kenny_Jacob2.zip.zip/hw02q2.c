#include <stdio.h>
#pragma warning(disable : 4996)
#define addm(x, y) (x + y)
#define squared_subm(x, y) ((x * x) - (y * y))
#define absm(x) ((x < 0) ? -(x) : x)
#define evenm(x) ((x % 2 == 0 ) ? 1 : 0)

int main (){
    int a = -5, b = 2, result;

    int addf(int a, int b) {
        return a + b;
    }
    int squared_subf(int a, int b) {
        return a * a - b * b;
    }
    int absf(int a) {
        if (a < 0) {
            return -a;
        }
        else {
            return a;
        }
    }
    int evenf(int a) {
        if (a % 2 == 0) {
            return 1;
        }
        else {
            return 0;
        }
    }

    result = addf(a, b);
    printf("addf(a, b) = %d\n", result);
    result = addm(a, b);
    printf("addm(a, b) = %d\n", result);
    result = addf(++a, b--);
    printf("addf(++a, b-- = %d\n", result);
    a = -5, b = 2; // reset a, b values;
    result = addm(++a, b--);
    printf("addm(++a, b--) = %d\n", result);

    a = -5; b = 2;
    result = squared_subf(a, b);
    printf("squared_subf(a, b) = %d\n", result);
    result = squared_subm(a, b);
    printf("squared_subm(a, b) = %d\n", result);
    result = squared_subf(a++, --b);
    printf("squared_subf(++a, b--) = %d\n", result);
    a = -5; b = 2;
    result = squared_subm(a++, --b);
    printf("squared_subm(++a, b--) = %d\n", result);

    a = -5; b = 2;
    result = absf(a);
    printf("absf(a) = %d\n", result);
    result = absm(a);
    printf("absm(a) = %d\n", result);
    result = absf(++a);
    printf("absf(++a) = %d\n", result);
    a = -5; b = 2;
    result = absm(++a);
    printf("absm(++a) = %d\n", result);

    a = -5; b = 2;
    result = evenf(b);
    printf("evenf(b) = %d\n", result);
    result = evenm(b);
    printf("evenm(b) = %d\n", result);
    result = evenf(b++);
    printf("evenf(b++) = %d\n", result);
    a = -5; b = 2;
    result = evenm(b++);
    printf("evenm(b++) = %d\n", result);
}