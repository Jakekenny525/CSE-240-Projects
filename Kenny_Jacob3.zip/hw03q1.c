// CSE240 Fall 2020 HW3

// Jake Kenny
// State the IDE that you use: Visual Studio

#include <stdio.h>
#include <string.h>
#include <ctype.h>


#pragma warning(disable : 4996)  // compiler directive for Visual Studio only

// Read before you start:
// You are given a partially complete program. Your job is to complete the functions in order for this program to work successfully.
// All instructions are given above the required functions, please read them and follow them carefully. 
// You shoud not modify the function return types or parameters.
// You can assume that all inputs are valid. Ex: If prompted for an integer, the user will input an integer.

// Global Macro Values. They are used to define the size of 2D array of integers
#define NUM_ROWS 5
#define NUM_COLUMNS 5

#define NUM_STRINGS 5 
#define STRING_LENGTH 50

// Forward Declarations
void printMatrix(int[NUM_ROWS][NUM_COLUMNS]);
void printMatrixDiagonal(int[NUM_ROWS][NUM_COLUMNS]);
void sumMatrixRows(int[NUM_ROWS][NUM_COLUMNS]);
void rotateMatrixRows(int[NUM_ROWS][NUM_COLUMNS], int);
void transposeMatrix(int[NUM_ROWS][NUM_COLUMNS]);
void multiplyMatrix(int[NUM_ROWS][NUM_COLUMNS], int[NUM_ROWS][NUM_COLUMNS]);
int splitAndPrintWords(char s[NUM_STRINGS * STRING_LENGTH]);
void filterChar(char s[NUM_STRINGS * STRING_LENGTH], char);


// Problem 1: printMatrix (5 points)
// Traverse the 2D array of integers variable 'matrix' (input from main)
// and print the contents in the following format (actual contents may vary)
// 1 2 3 4 5
// 6 7 8 9 10
// 11 12 13 14 15
// 16 17 18 19 20
// 21 22 23 24 25
void printMatrix(int matrix[NUM_ROWS][NUM_COLUMNS]) 
{
	for(int i = 0; i < NUM_ROWS; i++){
		for(int j = 0; j < NUM_COLUMNS; j++){
			printf("%3d ", matrix[i][j]);
		}
		printf("\n");
	}
}

// Problem 2: printMatrixDiagonal (5 points)
// Traverse the 2D array of integers 'matrix' and print each value on the diagonal from the 
// top left to bottom right position.
// e.g.
// 1 2 3		1 5 9
// 4 5 6	=>
// 7 8 9
void printMatrixDiagonal(int matrix[NUM_ROWS][NUM_COLUMNS])
{
	for(int i = 0; i < NUM_ROWS; i++){
		int col = i; 
		printf("%3d", matrix[i][col]);
	}
}

// Problem 3: sumMatrixRows (5 points)
// Traverse the 2D array of integers 'matrix' and print the sum of each row on its own line.
// e.g.
// 1 2 3       6
// 4 5 6	=> 15
// 7 8 9	   24
void sumMatrixRows(int matrix[NUM_ROWS][NUM_COLUMNS])
{
	for(int i = 0; i < NUM_ROWS; i++){
		int rowSum = 0;
		for(int j = 0; j < NUM_COLUMNS; j++){
			rowSum += matrix[i][j];
		}
		printf("%3d\n", rowSum);
	}
}

// Problem 4: rotateMatrixRows (5 points)
// Take the 2D array of integers 'matrix' and print the result of rotating each row to the right
// by the amount specified by the integer 'offset'. In other words, shift each entry position right by 'offset'.
// If shifting would move an integer off the end of the row, it moves to the beginning of the row.
// **Hint: Use printMatrix to print the result**
// e.g.
// 1 2 3           3 1 2
// 4 5 6       	=> 6 4 5
// 7 8 9           9 7 8
void rotateMatrixRows(int matrix[NUM_ROWS][NUM_COLUMNS], int offset) 
{
	int matrix2[NUM_ROWS][NUM_COLUMNS];
	for(int i = 0; i < NUM_ROWS; i++){
		for(int j = 0; j < NUM_COLUMNS; j++){
			int place; 
			if(j + offset > NUM_COLUMNS - 1){
				place = j + offset - NUM_COLUMNS;
			}
			else{
				place = j + offset; 
			}
			matrix2[i][place] = matrix[i][j];
		}
	}
	printMatrix(matrix2);
}

// Problem 5: transposeMatrix (10 points)
// Take the 2D array of integers 'matrix' and print the tranpose matrix.
// You may assume that row and column counts are equal.
// **Hint: Use printMatrix to print the result**
// e.g.
// 1 2 3	    1 4 7
// 4 5 6	=>  2 5 8
// 7 8 9        3 6 9
void transposeMatrix(int matrix[NUM_ROWS][NUM_COLUMNS])
{
	int matrix2[NUM_ROWS][NUM_COLUMNS];
	// Enter code below
	for(int i = 0; i < NUM_COLUMNS; i++){
		for(int j = 0; j < NUM_ROWS; j++){
			matrix2[i][j] = matrix[j][i];
		}
	}
	printMatrix(matrix2);
}

// Problem 6: multiplyMatrix (10 points)
// Take two 2D arrays of integers 'matrix1' and 'matrix2' and print the 
// resulting matrix gained by multiplying the entries in each corresponding location.
// You can assume the two matrices will have the same dimensions.
// **Hint: Use printMatrix to print the result**
// e.g.
// 1 2 3	1 2 3      1 4 9
// 4 5 6	4 5 6  =>  16 25 36
// 7 8 9    7 8 9      49 64 81
void multiplyMatrix(int matrix1[NUM_ROWS][NUM_COLUMNS], int matrix2[NUM_ROWS][NUM_COLUMNS])
{
	int matrixResult[NUM_ROWS][NUM_COLUMNS];
	// Enter code below
	for(int i = 0; i < NUM_ROWS; i++){
		for(int j = 0; j < NUM_COLUMNS; j++){
			int product = matrix1[i][j] * matrix2[i][j];
			matrixResult[i][j] = product;
		}
	}
	printMatrix(matrixResult);
}

// Problem 7: splitAndPrintWords (5 points)
// Split s[] into individual words and store them in str[][].
// Read s[] character by character and copy into str[][], such that word 1 is in str[0][], 
// word 2 is in str[1][], and so on. Print the char array str[][], so that the separated words are 
// printed on their own line. Finally return the number of words using the variable 'count'.
// Don't forget to initialize str[][] with the null terminator character '\0'.
// Hint: Words are separated by whitespace characters
// e.g. 
// "The quick brown fox jumped over the lazy dog"
// The
// quick
// brown
// fox
// jumped
// over
// the
// lazy
// dog
int splitAndPrintWords(char s[NUM_STRINGS*STRING_LENGTH])
{
	char str[NUM_STRINGS][STRING_LENGTH];
	int count = 0;
	// enter code below
	int size; 
	int col; 
	size = strlen(s);
	col = 0;
	for(int i = 0; i < size; i++){
		if(isspace(s[i]) != 0){ //If char is a space 
			col = 0;
			count++;
			printf("\n");
		}
		else{
			str[count][col] = s[i];
			col++;
			printf("%c", s[i]);
		}
	}
	return count;
}

// Problem 8: filterChar (5 points)
// Remove all occurrences of the specified character 'filter' from s[].
// Use the resulting array as input to splitAndPrintWords. 
// *** NOTE: If you were unable to code for splitAndPrintWords(), then skip this step and just filter out the char.
//			You will earn partial points for that case.
void filterChar(char s[NUM_STRINGS * STRING_LENGTH], char filter)
{
	for(int i = 0; i < strlen(s); i++){
		if(s[i] == filter){
			for(int j = i; j < strlen(s); j++){
				s[j] = s[j + 1];
			}
		}
	}
	splitAndPrintWords(s);
}

// You should study and understand how this main() works.
// *** DO NOT modify it in any way ***
int main()
{
	printf("CSE240 HW3: 2D Integer Arrays\n\n");
	
	int matrix[NUM_ROWS][NUM_COLUMNS] = 
	{
		{1, 2, 3, 4, 5},
		{6, 7, 8, 9, 10},
		{11, 12, 13, 14, 15},
		{16, 17, 18, 19, 20},
		{21, 22, 23, 24, 25}
	};

	printMatrix(matrix);
	printf("\n\n");
	printMatrixDiagonal(matrix);
	printf("\n\n");
	sumMatrixRows(matrix);
	printf("\n\n");
	rotateMatrixRows(matrix, 1);
	printf("\n\n");
	transposeMatrix(matrix);
	printf("\n\n");
	multiplyMatrix(matrix, matrix);

	printf("\nCSE240 HW3: 2D Character Arrays\n\n");

	char words[NUM_STRINGS*STRING_LENGTH];
	int i = getchar();
	printf("\nEnter words (max 5): ");
	fgets(words, sizeof(words), stdin);
	int count = splitAndPrintWords(words);
	printf("\nNumber of words= %d \n", count);
	

	filterChar(words, 'a');
	i = getchar();
	i = getchar(); // Keep console open
	return 0;
}
