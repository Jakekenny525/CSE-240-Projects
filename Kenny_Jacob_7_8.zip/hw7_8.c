// CSE240 Fall 2020 HW 7 & 8
// Jake Kenny
// Visual Studio

// READ BEFORE YOU START:
// You are given a partially completed program that creates a linked list of employee information.
// The global linked list 'list' is a list of employees with each node being struct 'employeeList'.
// 'employeeList' consists of struct 'employee' which has: employee name, room number, and a linked list of 'supervisors'.
// The linked list of supervisors has each node containing simply the name of the supervisor.
// HW7 ignores the 'supervisors' linked list since there is no operation/manipulation to be done on 'supervisors' list in HW7.
// HW8 has operations/manipulations to be done with 'supervisors' list like add a supervisor, display last added supervisor.

// To begin, you should trace through the given code and understand how it works.
// Please read the instructions above each required function and follow the directions carefully.
// If you modify any of the given code, the return types, or the parameters, you risk getting compile error.
// You are not allowed to modify main ().
// You can use string library functions.

// ***** WRITE COMMENTS FOR IMPORANT STEPS OF YOUR CODE. *****
// ***** GIVE MEANINGFUL NAMES TO VARIABLES. *****
// ***** Before implementing any function, see how it is called in executeAction() *****


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma warning(disable: 4996) // for Visual Studio

#define MAX_NAME 30

// global linked list 'list' contains the list of employees
struct employeeList {
	struct employee* employee;
	struct employeeList* next;
} *list = NULL;				// currently empty list

// structure "employee" contains the employee's name, room number and linked list of supervisors
struct employee {
	char name[MAX_NAME];
	unsigned int roomNumber;
	struct supervisor* supervisors;		// linked list 'supervisors' contains names of supervisors
};

//  structure 'supervisor' contains supervisor's name 
struct supervisor {
	char name[MAX_NAME];
	struct supervisor* next;
};

// forward declaration of functions (already implmented)
void flushStdIn();
void executeAction(char);

// functions that need implementation:
// HW 7
void addEmployee(char* employeeNameInput, unsigned int roomNumInput); // 20 points
void displayEmployeeList(struct employeeList* tempList);	      // 15 points
struct employee* searchEmployee(char* employeeNameInput);	      // 15 points
//HW 8
void addSupervisor(char* employeeNameInput, char* supervisorNameInput);	// 15 points
void displayEmployeeSupervisorList(struct employeeList* tempList);	// 15 points
void removeEmployee(char* employeeNameInput);			        // 20 points

int main()
{
	char selection = 'a';		// initialized to a dummy value
	do
	{
		printf("\nCSE240 HW 7,8\n");
		printf("Please enter your selection:\n");
		printf("HW7:\n");
		printf("\t a: add a new employee to the list\n");
		printf("\t d: display employee list (no supervisors)\n");
		printf("\t b: search for an employee on the list\n");
		printf("\t q: quit\n");
		printf("HW8:\n");
		printf("\t c: add a supervisor of a employee\n");
		printf("\t l: display employees who report to a specific supervisor\n");
		printf("\t r: remove an employee\n");
		printf("\t q: quit\n");

		selection = getchar();
		flushStdIn();
		executeAction(selection);
	} while (selection != 'q');

	return 0;
}

// flush out leftover '\n' characters
void flushStdIn()
{
	char c;
	do c = getchar();
	while (c != '\n' && c != EOF);
}

// Ask for details from user for the given selection and perform that action
// Read the function case by case
void executeAction(char c)
{
	char employeeNameInput[MAX_NAME], supervisorNameInput[MAX_NAME];
	unsigned int roomNumInput;
	struct employee* searchResult = NULL;

	switch (c)
	{
	case 'a':	// add employee
				// input employee details from user
		printf("\nPlease enter employee's name: ");
		fgets(employeeNameInput, sizeof(employeeNameInput), stdin);
		employeeNameInput[strlen(employeeNameInput) - 1] = '\0';	// discard the trailing '\n' char
		printf("Please enter room number: ");
		scanf("%d", &roomNumInput);
		flushStdIn();

		if (searchEmployee(employeeNameInput) == NULL)	// un-comment this line after implementing searchEmployee()					
		//if (1)									// comment out this line after implementing searchEmployee()
		{
			addEmployee(employeeNameInput, roomNumInput);
			printf("\nEmployee successfully added to the list!\n");
		}
		else
			printf("\nThat employee is already on the list!\n");
		break;

	case 'd':		// display the list
		displayEmployeeList(list);
		break;

	case 'b':		// search for an employee on the list
		printf("\nPlease enter employee's name: ");
		fgets(employeeNameInput, sizeof(employeeNameInput), stdin);
		employeeNameInput[strlen(employeeNameInput) - 1] = '\0';	// discard the trailing '\n' char

		if (searchEmployee(employeeNameInput) == NULL)	// un-comment this line after implementing searchEmployee()					
		//if (0)											// comment out this line after implementing searchEmployee()
			printf("\nEmployee name does not exist or the list is empty! \n\n");
		else
		{
			printf("\nEmployee name exists on the list! \n\n");
		}
		break;

	case 'r':		// remove employee
		printf("\nPlease enter employee's name: ");
		fgets(employeeNameInput, sizeof(employeeNameInput), stdin);
		employeeNameInput[strlen(employeeNameInput) - 1] = '\0';	// discard the trailing '\n' char

		if (searchEmployee(employeeNameInput) == NULL)	// un-comment this line after implementing searchEmployee()					
		//if (0)									// comment out this line after implementing searchEmployee()
			printf("\nEmployee name does not exist or the list is empty! \n\n");
		else
		{
			removeEmployee(employeeNameInput);
			printf("\nEmployee successfully removed from the list! \n\n");
		}
		break;

	case 'c':		// add supervisor
		printf("\nPlease enter employee's name: ");
		fgets(employeeNameInput, sizeof(employeeNameInput), stdin);
		employeeNameInput[strlen(employeeNameInput) - 1] = '\0';	// discard the trailing '\n' char

		if (searchEmployee(employeeNameInput) == NULL)	// un-comment this line after implementing searchEmployee()					
		//if (0)										// comment out this line after implementing searchEmployee()
			printf("\nEmployee name does not exist or the list is empty! \n\n");
		else
		{
			printf("\nPlease enter supervisor's name: ");
			fgets(supervisorNameInput, sizeof(supervisorNameInput), stdin);
			supervisorNameInput[strlen(supervisorNameInput) - 1] = '\0';	// discard the trailing '\n' char

			addSupervisor(employeeNameInput, supervisorNameInput);
			printf("\nSupervisor added! \n\n");
		}
		break;

	case 'l':		// list supervisor's employees
		displayEmployeeSupervisorList(list);
		break;

	case 'q':		// quit
		break;

	default: printf("%c is invalid input!\n", c);
	}
}

// HW7 Q1: addEmployee (20 points)
// This function is used to insert a new employee in the linked list. 
// You must insert the new employee to the head of linked list 'list'.
// You need NOT check if the employee already exists in the list because that is taken care by searchEmployee() called in executeAction(). Look at how this function is used in executeAction().
// Don't bother to check how to implement searchEmployee() while implementing this function. Simply assume that employee does not exist in the list while implementing this function.
// NOTE: The function needs to add the employee to the head of the list.
// NOTE: This function does not add supervisors to the employee info. There is another function addSupervisor() in HW8 for that.
// Hint: In this question, no supervisors means NULL supervisors.

void addEmployee(char* employeeNameInput, unsigned int roomNumInput)
{
	struct employee* newEmp; //The employee to be added
	struct employeeList* newHead; //The new head node in the linked list 
	//initialize newEmp
	newEmp = (struct employee*)malloc(sizeof(struct employee));
	strcpy(newEmp->name, employeeNameInput);
	newEmp->roomNumber = roomNumInput;
	newEmp->supervisors = NULL;
	//if list has 0 elements
	if(list == NULL){
		list = (struct employeeList*)malloc(sizeof(struct employeeList));
		list->employee = newEmp;
		list->next = NULL;
	}
	else{ //if list size > 0, adds newHead to the front of the linked list and sets "list" equal to "newHead"
		newHead = (struct employeeList*)malloc(sizeof(struct employeeList));
		newHead->employee = newEmp;
		newHead->next = list;
		list = newHead;
	}
	return;
}

// HW7 Q2: displayEmployeeList (15 points)
// This function displays the employee details (struct elements) of each employee.
// Parse through the linked list 'list' and print the employee details ( name and room number) one after the other. See expected output screenshots in homework question file.
// You should not display supervisor names (because they are not added in HW7).
// You MUST use recursion in the function to get full points. Notice that 'list' is passed to the function argument. Use recursion to keep calling this function till end of list.

void displayEmployeeList(struct employeeList* tempList)
{
	if(tempList != NULL){
		printf("\nName: %s\n", tempList->employee->name);
		printf("Room Number: %d\n", tempList->employee->roomNumber);
		displayEmployeeList(tempList->next); //recursively calls displayEmployeeList until its parameter is NULL
	}
	else{
		printf("\n(end of list)\n");
	}
	return;
}

// HW7 Q3: searchEmployee (15 points)
// This function searches the 'list' to check if the given employee exists in the list. Search by employee name.
// If it exists then return that 'employee' node of the list. Notice the return type of this function.
// If the employee does not exist in the list, then return NULL.
// NOTE: After implementing this fucntion, go to executeAction() to comment and un-comment the lines mentioned there which use searchEmployee()
//       in case 'a', case 'r', case 'l' (total 3 places)
struct employee* searchEmployee(char* employeeNameInput)
{
	struct employeeList* tempList = list;			// work on a copy of 'list'
	while(tempList != NULL){						//iterates through tempList
		if(strcmp(tempList->employee->name, employeeNameInput) == 0){ //if name is found in the list, return employee
			return tempList->employee;
		}
		tempList = tempList->next;
	}
	return NULL; //if no name is found return NULL
}



// HW8 Q1: addSupervisor (15 points)
// This function adds supervisor's name to a employee node.
// Parse the list to locate the employee and add the supervisor to that employee's 'supervisors' linked list. No need to check if the employee name exists on the list. That is done in executeAction().
// If the 'supervisors' list is empty, then add the supervisor. If the employee has existing supervisors, then you may add the new supervisor to the head or the tail of the 'supervisors' list.
// You can assume that the same supervisor name does not exist. So no need to check for existing supervisor names, like we do when we add new employee.
// NOTE: Make note of whether you add the supervisor to the head or tail of 'supervisors' list. You will need that info when you implement lastSupervisor()
//       (Sample solution has supervisor added to the tail of 'supervisors' list. You are free to add new supervisor to head or tail of 'supervisors' list.)

void addSupervisor(char* employeeNameInput, char* supervisorNameInput)
{

	struct employeeList* tempList = list;		// work on a copy of 'list'
	struct supervisor* newSup;					//new supervisor to be added
	
	// YOUR CODE HERE
	while(tempList != NULL && strcmp(tempList->employee->name, employeeNameInput) != 0){ //iterates through tempList (if it's not empty) until said employee is found
		tempList = tempList->next;
	}
	if(tempList->employee->supervisors == NULL){ //if supervisor list is empty
		tempList->employee->supervisors = (struct supervisor*)malloc(sizeof(struct supervisor));
		strcpy(tempList->employee->supervisors->name, supervisorNameInput);
		tempList->employee->supervisors->next = NULL;
	}
	else{ //adds supervisor to head of list if list is not empty
		newSup = (struct supervisor*)malloc(sizeof(struct supervisor));
		strcpy(newSup->name, supervisorNameInput);
		newSup->next = tempList->employee->supervisors;
		tempList->employee->supervisors = newSup;
	}
	return;
}

// HW8 Q2: displayEmployeeSupervisorList (15 points)
// This function prompts the user to enter a supervisor name. This function then searches for employees with this supervisor.
// Parse through the linked list passed as parameter and print the matching employee details ( name and room number) one after the other. See expected output screenshots in homework question file.
// HINT: Use inputs gathered in executeAction() as a model for getting the supervisor name input.
// NOTE: You may re-use some HW7 Q2 displayEmployeeList(list) code here.
void displayEmployeeSupervisorList(struct employeeList* tempList)
{
	// YOUR CODE HERE
	char sup[MAX_NAME]; //Supervisor to be searched
	printf("Please enter supervisor's name:\n");
	fgets(sup, sizeof(sup), stdin); 
	sup[strlen(sup) - 1] = '\0'; //Eliminate trailing '\n' character
	struct employeeList* copy = tempList; //Work with a copy of tempList
	struct supervisor* supCopy; 
	while(copy != NULL){
		printf("\n");
		supCopy = copy->employee->supervisors; //work on a copy of the employee's supervisors
		while(supCopy != NULL){
			if(strcmp(supCopy->name, sup) == 0){
				printf("Employee Name: %s\nRoom Number: %d\n", copy->employee->name, copy->employee->roomNumber);
				break;
			}
			supCopy = supCopy->next;
		}
		copy = copy->next;
	}
	free(copy);
	free(supCopy);
	return;
}


// HW8 Q3: removeEmployee (20 points)
// This function removes an employee from the list.
// Parse the list to locate the employee and delete that 'employee' node.
// You need not check if the employee exists because that is done in executeAction()
//removeEmployee() is supposed to remove employee details like name and room number.
// The function will remove supervisors of the employee too.
// When the employee is located in the 'list', after removing the employee name and room number, parse the 'supervisors' list of that employee
// and remove the supervisors.

void removeEmployee(char* employeeNameInput)
{

	struct employeeList* tempList = list;	// work on a copy of 'list'
	// YOUR CODE HERE
	struct employeeList* head = tempList; //used to return to the head of the linked list after iterating through it
	struct employeeList* prev = NULL; //the previous node in the linked list, first initialized to NULL
	for(; tempList != NULL; prev = tempList, tempList = tempList->next){
		if(strcmp(tempList->employee->name, employeeNameInput) == 0){
			if(prev == NULL){ //If there is only one item in tempList
				tempList = NULL;
			}
			else{
				prev->next = tempList->next;
				free(tempList);
				tempList = head;
			}
			list = tempList;
			break;
		}
	}

}


