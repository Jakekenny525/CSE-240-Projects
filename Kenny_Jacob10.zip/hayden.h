#ifndef _HAYDEN_H_
#define _HAYDEN_H_
#include "book.h"
#include <string>
using namespace std;
// Q1b: Create Hayden class (5 points)
// Part 1: Create a child class of the Book class named 'Hayden'
class Hayden: public Book {
// Part2: Declare constructor which accepts the same 3 parameters as the parent class Book's constructor.
// Pass the 3 parameters to the super constructor of the Book class.
    public:
        Hayden(string bookName, double price, libraryType libType): Book(bookName, price, libType){bookName = bookName, price = price, libType = libType;};
// Part 3: Re-declare the method displayBook (virtual method found inside of parent class Book)
        void displayBook();
};
#endif // _HAYDEN_H_