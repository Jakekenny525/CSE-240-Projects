/* Database for family tree. It consists of facts and rules. */
/* A portion of the family tree has been implemented for you */
/* Facts */
male(kam).
male(rob).
male(dom).
male(jeb).
male(tio).
male(dag).
male(zev).
male(gio).
female(ana).
female(syd).
female(fey).
female(sue).
female(kat).
female(pam).
female(liz).
father_of(kam, rob). /* kam is the father of rob */
father_of(kam, syd). /* kam is the father of syd */
father_of(rob, dom). /* rob is the father of dom */
father_of(rob, kat).
father_of(tio, dag).
father_of(tio, fey).
father_of(zev, gio).
father_of(zev, liz).
father_of(jeb, tio).
father_of(jeb, pam).
mother_of(ana, rob). /* ana is the mother of rob */
mother_of(ana, syd). /* ana is the mother of syd */
mother_of(may, tio).
mother_of(may, pam).
mother_of(sue, dom).
mother_of(sue, kat).
mother_of(syd, dag).
mother_of(syd, fey).
mother_of(pam, gio).
mother_of(pam, liz).


/* Rules */
is_male(X) :-
male(X);
father_of(X, _).

is_female(X) :-
female(X);
mother_of(X, _).

parent_of(X, Y) :-
father_of(X, Y);
mother_of(X, Y).

sibling_of(X, Y) :-
parent_of(_, X),
parent_of(_, Y).

grandmother_of(X, Z) :-
mother_of(X, Y),
parent_of(Y, Z).

grandfather_of(X, Z) :-
father_of(X, Y),
parent_of(Y, Z).

descendant_of(X, Y) :-
parent_of(Y, X);
parent_of(Z, X),
descendant_of(Z, Y).
