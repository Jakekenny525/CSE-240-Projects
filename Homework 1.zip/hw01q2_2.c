#include <stdio.h>
float main(){
	char ch;
	double a = 10, b = 20, f;
	for(int i = 0; i <= 4; i++){
		printf("Please enter a char: ");
		ch = getchar();
		switch (ch){
			case '+': 
				f = a + b;
				printf("f = %.0f\n", f);
				break;
			case '-':
				f = a - b;
				printf("f = %.0f\n", f);
				break;
			case '*':
				f = a * b;
				printf("f = %.0f\n", f);
				break;
			case '/':
				f = a / b;
				printf("f = %.1f\n", f);
				break;
			default:
				printf("invalid operator\n");
				break;
			ch = getchar();
		}
			ch = getchar();
	}
}