#include "noble.h"
#include <iostream>
// Q2b: Define displayBook() for Noble class (5 points)
// Define the function displayBook() that you declared within the Noble class in the header file
// See expected output in question file.

// (displayList() function in hw10.cpp should call this function.)
// Include necessary header files
void Noble::displayBook(){
    cout << "Book Name: " << this->getName() << endl;
    cout << "Price: " << this->getPrice() << endl;
    cout << "Library: Noble" << endl << endl;
}