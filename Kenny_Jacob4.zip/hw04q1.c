//CSE240 Fall 2020 HW4

// Jake Kenny
// State the IDE that you use: Visual Studio 

#include <stdio.h>
#include <string.h>

#pragma warning(disable : 4996)  // compiler directive for Visual Studio only

// Read before you start:
// You are given a partially complete program. Complete the functions in order for this program to work successfully.
// All instructions are given above the required functions, please read them and follow them carefully. 
// You shoud not modify the function return types or parameters.
// You can assume that all inputs are valid. Ex: If prompted for an integer, the user will input an integer.
// You can use only the strlen() of strings.h library to check string length. Do not use any other string functions 
// because you are supposed to use pointers for this homework. 
// **** DO NOT use arrays to store or to index the characters in the string ****

// Global Macro Values. They are used to define the size of 2D array of characters
#define NUM_STRINGS 4
#define STRING_LENGTH 50

// Forward Declarations
void initializeStrings(char[NUM_STRINGS][STRING_LENGTH]);
void printStrings(char[NUM_STRINGS][STRING_LENGTH]);
void toUppercase(char[STRING_LENGTH]);
void toLowercase(char[STRING_LENGTH]);
void changeAllToUpperOrLower(char[NUM_STRINGS][STRING_LENGTH], char);
void encryptStrings(char[NUM_STRINGS][STRING_LENGTH], int);
void decryptStrings(char[NUM_STRINGS][STRING_LENGTH], int);
void concatStrWithStrrev(char[STRING_LENGTH * 2], char[STRING_LENGTH]);


// Problem 1: initializeStrings (5 points)
// Use pointer 'p' to traverse the 2D array of characters variable 'strings' (input from user in main() ) and set all characters in each
// array to a null terminator so that there is a 4 row and 50 column 2D array full of null terminators.
// The null terminator '\0' is used to denote the end of a string.
void initializeStrings(char strings[NUM_STRINGS][STRING_LENGTH])
{
	char* p = &strings[0][0];
	// enter code here
	for(; p < &strings[NUM_STRINGS][STRING_LENGTH]; p++){
		*p = '\0';
	}
}

// Problem 2: printStrings (5 points)
// Use pointer 'p' to traverse the 2D character array 'strings' and print each string.
// See the example outputs provided in the word document. Each string should be printed on a new line.
void printStrings(char strings[NUM_STRINGS][STRING_LENGTH])
{
	char* p = &strings[0][0];
	// enter code here
	do{
		if(*p == '\0' && *(p + 1) != '\0'){ //Starts a new line before the next String begins
			printf("%c\n", *p);
		}
		else{
			printf("%c", *p);
		}

		p++;
	}
	while(p <= &strings[NUM_STRINGS - 1][STRING_LENGTH - 1]);
}

// Problem 3: toUppercase() and toLowercase() (15 points)
// Problem 3-1: toUppercase 
// Convert the string in the array 's' to an uppercase string.
// Traverse the input using pointer 'p' and covert the character to an uppercase letter if it is lowercase.
// You need to write down the code to check whether or not the character is lowercase.
// HINT: Use a pointer to change the ASCII value of a character.
//       The ASCII value of 'a'= 97 and the ASCII value of 'A' = 65 so the difference between them is 32.
void toUppercase(char s[STRING_LENGTH]) {
	char* p = &s[0];
	// enter code here
	int asciiVal;
	int newAsciiVal;
	for(int i = 0; i < STRING_LENGTH; i++){
		asciiVal = *p; 
		if((97 <= asciiVal && asciiVal <= 122)){ //if *p is a lowercase letter
			newAsciiVal = asciiVal - 32;
			*p = (char)newAsciiVal;
		}
	}
	return;
}

// Problem 3-2: toLowercase 
// HINT : This should be very similar to toUppercase().
// Convert the string in the array 's' to an lowercase string.
// Traverse the input using pointer 'p' and covert the character to a lowercase letter if it is uppercase.
// You need to write down the code to check whether or not the character is uppercase.
// HINT: Use a pointer to change the ASCII value of a character.
//       The ASCII value of 'a'= 97 and the ASCII value of 'A' = 65 so the difference between them is 32.
void toLowercase(char s[STRING_LENGTH]) {
	char* p = &s[0];
	// enter code here
	int asciiVal;
	int newAsciiVal;
	for(int i = 0; i < STRING_LENGTH; i++){
		asciiVal = *p; 
		if((65 <= asciiVal && asciiVal <= 90)){ //if *p is an uppercase letter
			newAsciiVal = asciiVal + 32;
			*p = (char)newAsciiVal;
		}
	}
	return;
}



// Problem 4: changeAllToUpperOrLower (5 points)
// Change all words in the array 'strings' to uppercase or lowercase based on the value of char variable 'set'.
// If the value of char 'set' is 'u' or 'U', change all words to uppercase strings.
// If the value of char 'set' is 'l' or 'L', change all words to lowercase strings.
// No change, otherwise.
// You may use toUppercase() and toLowercase() here.
void changeAllToUpperOrLower(char strings[NUM_STRINGS][STRING_LENGTH], char set) {
	char* ptr = &strings[0][0];
	// enter code here
	char* s = &set;
	do{
		toUppercase(s);
		switch(set){
			case 'L':
				toLowercase(ptr);
				break;
			case 'U':
				toUppercase(ptr);
				break;
			default:
				break;
		}
		ptr++;
	}
	while(ptr < &strings[NUM_STRINGS][STRING_LENGTH]);
	
}


// Problem 5: encryptStrings (5 points)
// Use pointer 'p' to traverse the 2D character array 'strings' and encrypt each string in 2 step as follows- 
// 1) Change all strings to uppercase strings. Hint: Use 'changeAllToUpperOrLower()' for this step.
// 2) Shift the characters backward by the integer value of 'key'.
// If the string is "hello" and key = 2, Changing the string to uppercase string will get you "HELLO" and substracting key to it will result in "FCJJM".
// Once the value of 'key' gets larger, you will extend past alphabetical characters and reach non-alphabetical characters. Thats ok.
// NOTE: DO NOT encrypt the null terminator character. Use the null terminator to find the end string.
//		 If you could not implement changeAllToUpperOrLower(), skip using it in this function. You will receive partial credit.
void encryptStrings(char strings[NUM_STRINGS][STRING_LENGTH], int key)
{
	char* p = &strings[0][0];
	// enter code here
	changeAllToUpperOrLower(strings, 'U'); 
	int asciiVal, shiftVal;
	do{
		asciiVal = *p;
		shiftVal = key;
		if(*p != '\0'){ //encrypts everything but null terminator characters
			int newAsciiVal = asciiVal - shiftVal;
			*p = (char)newAsciiVal;
		}
		p++;
	}
	while(p <= &strings[NUM_STRINGS][STRING_LENGTH]);
	printf("\n");
}
// Problem 6: decryptStrings (5 points)
// HINT: This should be very similiar to the encryption function defined above in encryptStrings().
// Use pointer 'p' to traverse the 2D character array 'strings' and decrypt each string in 2 step as follows- 
// 1) Shift the characters forward by the integer value of 'key'.
// 2) Change all strings to lowercase. Hint: Use 'changeAllToUpperOrLower()' for this step.
// NOTE: DO NOT decrypt the null characters.
//		 If you could not implement changeAllToUpperOrLower(), skip using it in this function. You will receive partial credit.
void decryptStrings(char strings[NUM_STRINGS][STRING_LENGTH], int key)
{
	char* p = &strings[0][0];
	// enter code here
	int asciiVal, shiftVal;
	do{
		asciiVal = *p;
		shiftVal = key;
		if(*p != '\0'){ //null terminator characters were not encrypted, thus they don't need to be decrypted
			int newAsciiVal = asciiVal + shiftVal;
			*p = (char)newAsciiVal;
		}
		changeAllToUpperOrLower(strings, 'L'); 
		p++;
	}
	while(p <= &strings[NUM_STRINGS][STRING_LENGTH]);
	printf("\n");
}


// Problem 7: concatStrWithStrrev (10 points)
// This function must be working as follows:
// 1. Concatenate the string in the array 'input' (input from user in main()) with its reversed string.
// 2. Store the string to the array 'result'.
// 3. Print the string in the array 'result'.
// For example, if the input is "Computer", "ComputerretupmoC" must be printted.
// NOTE: This is the function partially containing what you have implemented so far.
//		 Initialize the array 'result' first before you store a string to it.
//		 You may declare and use more pointers if needed.
void concatStrWithStrrev(char result[STRING_LENGTH * 2], char input[STRING_LENGTH]) {
	char* p_result = result;
	char* p_input = input;
	// enter code here
	//initializeStrings(result);
	int length; //the length of the String
	length = 0;
	//Puts input[] into result[]
	do{
		*p_result = *p_input;
		p_result++;
		p_input++;
		length++;
	}
	while(*p_input != '\0');
	//Puts input[] backwards into result[] right after the original input[]
	p_input = &input[length];
	for(int i = length; i <= length * 2; i++){
		*p_result = *p_input;
		p_result++;
		p_input--;
	}
	//prints result[]
	for(p_result = &result[0]; p_result <= &result[length * 2]; p_result++){
		if(p_result != &result[length]){
			printf("%c", *p_result);
		}
	}
}


// You should study and understand how main() works.
// *** DO NOT modify it in any way ***
int main()
{
	char strings[NUM_STRINGS][STRING_LENGTH]; // will store four strings each with a max length of 34
	int i, key;
	char input[STRING_LENGTH];
	char result[STRING_LENGTH * 2];

	printf("CSE240 HW4: Pointers\n\n");
	initializeStrings(strings);

	for (i = 0; i < NUM_STRINGS; i++)
	{
		printf("Enter a string: ");				// prompt for string
		fgets(input, sizeof(input), stdin);		// store input string
		input[strlen(input) - 1] = '\0';		// convert trailing '\n' char to '\0' (null terminator)
		strcpy(strings[i], input);				// copy input to 2D strings array
	}

	printf("\nEnter a key value for encryption: "); // prompt for integer key
	scanf("%d", &key);

	printf("\nMake strings lowercase before encryption:\n");
	changeAllToUpperOrLower(strings, 'l');
	printStrings(strings);

	encryptStrings(strings, key);
	printf("\nEncrypted Strings:\n");
	printStrings(strings);
	decryptStrings(strings, key);
	printf("\nDecrypted Strings:\n");
	printStrings(strings);

	getchar();									// flush out newline '\n' char

	printf("\nConcatenating a string with its reversed string. Enter a string: ");	// prompt for string
	fgets(input, sizeof(input), stdin);			// store input string
	input[strlen(input) - 1] = '\0';			// convert trailing '\n' char to '\0' (null terminator)
	concatStrWithStrrev(result, input);

	getchar();									// keep VS console open
	return 0;
}