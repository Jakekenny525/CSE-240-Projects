// CSE240 Fall 2020 HW9
// Jake Kenny
// Write the compiler used: Visual studio 

// READ BEFORE YOU START:
// You are given a partially completed program which consist of a class 'Employee' defined in employee.h
// The definitions of class member functions are to be filled in employee.cpp.
// hw09q1.c (this file) creates an array of objects 'e[]' and uses a menu driven program to add a employee, display employee info, 
// sort the employee list and to find the employee with the longest name among the employees whose supervisor names contain a specific substring.
// You should start completing the program from from Q1. Question numbers are given around line 24 in employee.cpp.
// To begin, you should trace through the given code and understand how it works.
// Please read the instructions above each required function and follow the directions carefully.
// If you modify any of the given code, the return types, or the parameters, you risk getting compile error.

// ***** WRITE COMMENTS FOR IMPORANT STEPS OF YOUR CODE. *****
// ***** GIVE MEANINGFUL NAMES TO VARIABLES. *****

#include "employee.h"
#include <iostream>
#include <string.h>

#define MAX_EMPLOYEES 5

using namespace std;

// forward declaration of functions (already implmented)
void executeAction(char);

// functions that need implementation:
// in employee.cpp :
// Q1 Employee constructor		// 2 points
// Q2 Employee member functions // 18 points

// in this file (hw09q1.cpp) : Q3 to Q6
int addEmployee(string name_input, int id_input, int roomNumber_input, string supervisorName_input); // 10 points
void displayEmployees();				// 5 points
void sort();						// 10 points
void supervisorWithSpecificString();		// 5 points


Employee e[MAX_EMPLOYEES];		// array of objects
int currentCount = 0;				// number of employees in the list


int main()
{
	char choice = 'i';		// initialized to a dummy value
	do
	{
		cout << "\nCSE240 HW9\n";
		cout << "Please select an action:\n";
		cout << "\t a: add a new employee\n";
		cout << "\t d: display employee list\n";
		cout << "\t s: sort the employees in descending order based on ID (within a range)\n";
		cout << "\t n: display the employee with the longest name among the employees whose supervisor names contain a specific substring\n";
		cout << "\t q: quit\n";
		cin >> choice;
		cin.ignore();			// ignores the trailing \n
		executeAction(choice);
	} while (choice != 'q');

	return 0;
}


// Ask for details from user for the given selection and perform that action
// Read the function case by case
void executeAction(char c)
{
	string name_input, supervisorName_input;
	int ID_input, roomNumber_input, result = 0;

	switch (c)
	{
	case 'a':	// add employee
				// input employee details from user
		cout << "Please enter employee name: ";
		getline(cin, name_input);
		cout << "Please enter ID: ";
		cin >> ID_input;
		cin.ignore();
		cout << "Please enter room number: ";
		cin >> roomNumber_input;
		cin.ignore();
		cout << "Please enter supervisor name: ";
		getline(cin, supervisorName_input);

		// add the patient to the list
		result = addEmployee(name_input, ID_input, roomNumber_input, supervisorName_input);
		if (result == 0)
			cout << "\nThat employee is already in the list or list is full! \n\n";
		else
			cout << "\nEmployee successfully added to the list! \n\n";
		break;

	case 'd':		// display the list
		displayEmployees();
		break;

	case 's':		// sort the list
		sort();
		break;

	case 'n':		// find and display employee with the longest name among the employees whose supervisor names contain a specific substring.
		supervisorWithSpecificString();
		break;

	case 'q':		// quit
		break;

	default: cout << c << " is invalid input!\n";
	}

}

// Q3 addEmployee (10 points)
// This function adds a new employee with the details given in function arguments.
// Add the employee in 'e' (array of objects) only if there is remaining capacity in the array and if the employee does not already exist in the list (name or ID)
// This function returns 1 if the employee is added successfully, else it returns 0 for the cases mentioned above.
// Assume user enters ID and room number  in 0 - any positive integer range.
int addEmployee(string name_input, int id_input, int roomNumber_input, string supervisorName_input) 
{
	// enter code here
	if(currentCount == MAX_EMPLOYEES){ //Checks to see if list is full
		return 0;
	}
	else{
		for(int i = 0; i < currentCount; i++){
			if(name_input.compare(e[i].getName()) == 0){ //Checks to see if employee is already in list
				return 0;
			}
		}
		//adds employee to list and increments count by 1
		Employee newEmployee;
		newEmployee.setName(name_input);
		newEmployee.setID(id_input);
		newEmployee.setRoomNumber(roomNumber_input);
		newEmployee.setSupervisorName(supervisorName_input);
		e[currentCount] = newEmployee;
		currentCount++;
		return 1;
	}
	
}

// Q4 displayEmployees (5 points)
// This function displays the list of employees.
// Parse the object array 'e' and display the details of all employees in the array. See expected output given in question file.
// You can call the class function 'displayEmployee()' here. Note that these are two different functions.
// Employee::displayEmployee() displays details of one Employee object, while displayEmployees() should display all employees.
void displayEmployees()
{
	// enter code here
	for(int i = 0; i < currentCount; i++){
		e[i].displayEmployee();
	}
	return;
}

// Q5 sort (10 points)
// This function sorts the employees in descending order of ID, and then display the employees within a given range.
// You need to get lower bound of higher bound from user after printing a prompt. (Check the output in the pdf)
// You may use the 'temp' object for sorting logic, if needed.
void sort()
{
	Employee temp;
	int lower_bound;
	int higher_bound;
	// enter code here
	if(currentCount <= 0){
		return;
	}
	else{ //Sorts list if e[] isn't empty
		for(int i = 0; i < currentCount - 1; i++){
			for(int j = 1; j < currentCount; j++){
				if(e[i].getID() < e[j].getID()){
					temp = e[i];
					e[i] = e[j];
					e[j] = temp;
				}
			}
		}
	}
	//Gets lower and upper bounds from user, then displays all employees with IDs between those numbers
	cout << "Please enter the lower bound of ID: ";
	cin >> lower_bound;
	cout << "\nPlease enter the higher bound of ID: ";
	cin >> higher_bound;
	cout << "\n";
	int i = lower_bound;
	while(e[i].getID() <= higher_bound && i < currentCount){
		e[i].displayEmployee();
		i++;
	}
	return;
}

// Q6 supervisorWithSpecificString (5 points)
// This function displays an employee with the longest name among the employees whose supervisor names contain a specific substring.
// You should find the employee as follows:
// 1. By traversing all employees, you should find the employees whose supervisor names include a specific substring. 
// NOTE: you need to get a substring from user after printing a prompt. (Check the output in the pdf)
// HINT: You may refer to the document of string::find.
// 2. After step 1, you should find the employee whose name is the longest. You may use 'nameLength' and 'index' variable.
// 3. After step 2, copy the details of the employee to 'employeeWithLengthyName' object created using 'new' 
// and display the employee's details using 'employeeWithLengthyName' object.
// NOTE: You necessarily have to use the 'employeeWithLengthyName' object to store the employee details in it and delete it after displaying.
//       You should not display employee details using 'e[]' object.
// 4. Finally delete the 'employeeWithLengthyName' object.
void supervisorWithSpecificString()
{
	string subString;				// Ask the user for a character
	Employee* employeeWithLengthyName = new Employee;
	int nameLength = 0;				
	int index = -1;
	// enter code here
	cout << "Enter the substring of the employees' supervisor name: ";
	getline(cin, subString);
	for(int i = 0; i < currentCount; i++){ //Iterates through array
		if(e[i].getSupervisorName().find(subString) != std::string::npos){ //If supervisor contains subString
			if(e[i].getName().size() > nameLength){
				employeeWithLengthyName = &e[i];
				nameLength = e[i].getName().size();
			}
		}
	}
	if(nameLength > 0){
		employeeWithLengthyName->displayEmployee();
	}
	delete employeeWithLengthyName;
	return;
}
