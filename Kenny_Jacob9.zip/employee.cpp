// CSE240 Fall 2020 HW9
// Jake Kenny
// Write the compiler used: Visual studio

// READ BEFORE YOU START:
// You are given a partially completed program which consist of a class 'Employee' defined in employee.h
// The definitions of class member functions are to be filled in employee.cpp (this file).
// hw09q1.c creates an array of objects 'e[]' and uses a menu driven program to add a employee, display employee info, 
// sort the employee list and to find the employee by room number or the supervisor's name.
// You should start completing the program from from Q1. Question numbers are given around line 24.
// To begin, you should trace through the given code and understand how it works.
// Please read the instructions above each required function and follow the directions carefully.
// If you modify any of the given code, the return types, or the parameters, you risk getting compile error.

// ***** WRITE COMMENTS FOR IMPORANT STEPS OF YOUR CODE. *****
// ***** GIVE MEANINGFUL NAMES TO VARIABLES. *****

#include "employee.h"
#include <iostream>
#include <string.h>

using namespace std;

// Q1 Employee (2 points)
// Employee() constructor assigns the following default values to class data members
// name: John Doe
// ID: 0
// roomNumber: 101
// supervisorName: Jane Doe
Employee::Employee()
{
	// enter code here
	name = "John Doe";
	ID = 0;
	roomNumber = 101;
	supervisorName = "John Doe";
}

// Q2 (18 points)
// 2 points for each function

// Define all the class member functions.
// While defining member functions, note that these functions will be called using 
// a 'Employee' object which will represent one employee.
// Eg-  Employee e[10]; creates 10 Employee objects
//		e[2].setRoomNumber(202); will set 3rd employee's room number to 202.

// setName assigns 'name_input' to class data member 'name'
void Employee::setName(string name_input) {
	// enter code here
	this->name = name_input;
	return;
}

// setID assigns id_input to class data member 'ID'
void Employee::setID(int id_input) {
	// enter code here
	this->ID = id_input;
	return;
}

// setRoomNumber assigns roomNumber_input to class data member 'roomNumber'
void Employee::setRoomNumber(int roomNumber_input) {
	// enter code here
	this->roomNumber = roomNumber_input;
	return;
}

// setSupervisor assigns supervisorName_input to class data member 'supervisorName'
void Employee::setSupervisorName(string supervisorName_input) {
	// enter code here
	this->supervisorName = supervisorName_input;
	return;
}

// displayEmployee displays the name, ID, room number and supervisor of the employee
// See expected output in question file.
void Employee::displayEmployee() {
	// enter code here
	cout << "\nName: " << this->getName() << "\n";
	cout << "ID: " << this->getID() << "\n";
	cout << "Room Number: " << this->getRoomNumber() << "\n";
	cout << "Supervisor: " << this->getSupervisorName() << "\n";
}

// getName returns the class data member 'name'.
string Employee::getName() {
	// enter code here
	return this->name;
}

// getID returns the class data member 'ID'.
int Employee::getID() {
	// enter code here
	return this->ID;
}

// getRoomNumber returns the class data member 'roomNumber'.
int Employee::getRoomNumber() {
	// enter code here
	return this->roomNumber;
}

// getSupervisorName returns the class data member 'supervisorName'.
string Employee::getSupervisorName() {
	// enter code here
	return this->supervisorName;
}