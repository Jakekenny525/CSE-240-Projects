/*Facts*/

/*Rules*/
/*If Y <= 0, Z = X*/
foo(X, Y, Z) :-
   Y =< 0
   -> Z is X, !.

/*If X <= 0, Z = Y*/
foo(X, Y, Z) :-
    X =< 0
    -> Z is Y, !.

/*If X >= Y*/
foo(X, Y, Z) :-
    X >= Y,
    A is X - 2,
    foo(A, Y, Return),
    Z is X + Return.

/*If X < Y*/
foo(X, Y, Z) :-
    X < Y,
    A is Y - 3,
    foo(X, A, Return),
    Z is Y + Return.
