
// CSE240 Fall 2020 HW6
// Jake Kenny
// Write the compiler used: Visual studio 

// READ BEFORE YOU START:
// You are given a partially completed program that creates a list of patients, like patients' record.
// Each record has this information: employee's name, supervisors's name, department of the employee, room number.
// The struct 'employeeRecord' holds information of one employee. Department is enum type.
// An array of structs called 'list' is made to hold the list of employees.
// To begin, you should trace through the given code and understand how it works.
// Please read the instructions above each required function and follow the directions carefully.
// You should not modify any of the given code, the return types, or the parameters, you risk getting compile error.
// You are not allowed to modify main ().
// You can use string library functions.

// WRITE COMMENTS FOR IMPORANT STEPS IN YOUR CODE.


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma warning(disable: 4996) // for Visual Studio Only

#define MAX_EMPLOYEES 15
#define MAX_NAME_LENGTH 25

typedef enum {HR = 0, Marketing = 1, IT = 2} departmentType; // enum type 

struct employeeRecord {					// struct for emplyee details
	char employeeName[MAX_NAME_LENGTH];
	char supervisorName[MAX_NAME_LENGTH];
	departmentType department;
	unsigned int idNumber;
	unsigned int roomNumber;
	struct employeeRecord* next;
};
typedef struct employeeRecord EMP;

EMP* head = NULL;
int count = 0;

//functions to be implemented
void flushStdIn();
void save(char* fileName);
void load(char* fileName);
void executeAction(char c);
int add(char* employeeName_input, char* supervisorName_input, char* department_input, unsigned int idNumber_input, unsigned int roomNumber_input);
int delete(unsigned int idNumber_input);
void display();
void sort();
void swap(EMP* a, EMP* b);

int main(){
	char* fileName = "Employee_List.txt";
	head = malloc(sizeof(EMP));
	head = NULL;
	load(fileName);
	char choice = 'i';		// initialized to a dummy value
	do
	{
		printf("\nEnter your selection:\n");
		printf("\t a: add a new employee\n");
		printf("\t d: display employee list\n");
		printf("\t r: remove an employee from list\n");
		printf("\t s: sort employee list by ID\n");
		printf("\t q: quit\n");
		choice = getchar();
		flushStdIn();
		executeAction(choice);
	} while (choice != 'q');
	save(fileName);
	return 0;
}

//Gets rid of leftover "\n" characters
void flushStdIn()
{
	char c;
	do c = getchar();
	while (c != '\n' && c != EOF);
}

// ask for details from user for the given selection and perform that action
void executeAction(char c)
{
	char employeeName_input[MAX_NAME_LENGTH], supervisorName_input[MAX_NAME_LENGTH];
	unsigned int roomNumber_input, idNumber_input, add_result= 0;
	char department_input[20];
	switch (c)
	{
	case 'a':
		// input employee record from user
		printf("\nEnter employee name: ");
		fgets(employeeName_input, sizeof(employeeName_input), stdin);
		employeeName_input[strlen(employeeName_input) - 1] = '\0';	// discard the trailing '\n' char
		printf("Enter supervisor name: ");
		fgets(supervisorName_input, sizeof(supervisorName_input), stdin);
		supervisorName_input[strlen(supervisorName_input) - 1] = '\0';	// discard the trailing '\n' char
		printf("Enter whether employee is in 'HR' or 'Marketing' or 'IT': ");
		fgets(department_input, sizeof(department_input), stdin);
		department_input[strlen(department_input) - 1] = '\0';	// discard the trailing '\n' char
		printf("Please enter employee ID number: ");
		scanf("%d", &idNumber_input);
		printf("Please enter room number: ");
		scanf("%d", &roomNumber_input);
		flushStdIn();

		// add the employee to the list
		add_result = add(employeeName_input, supervisorName_input, department_input, idNumber_input, roomNumber_input);
		if (add_result == 0)
			printf("\nEmployee is already on the list! \n\n");
		else if (add_result == 1)
			printf("\nEmployee successfully added to the list! \n\n");
		else
			printf("\nUnable to add. Employee list is full! \n\n");

		break;
	case 'r': 
		printf("Please enter ID number of employee to be deleted: ");
		scanf("%d", &idNumber_input);
		flushStdIn();
		int delete_result = delete(idNumber_input);
		if (delete_result == 0)
			printf("\nEmployee not found in the list! \n\n");
		else 
			printf("\nEmployee deleted successfully! \n\n");
		break;
	case 'd': display();	break;
	case 's': sort();		break;
	case 'q': break;
	default: printf("%c is invalid input!\n", c);
	}
}

void load(char* fileName){
	EMP *temp, *employee;
	FILE* file;
	int i = 0, departmentValue = 0;
	file = fopen(fileName, "rb");
	if(file != NULL){
		fread(&count, sizeof(count), 1, file);
		for(; i < count; i++){
			employee = (EMP*)malloc(sizeof(EMP));
			fread(employee->employeeName, sizeof(head->employeeName), 1, file);
			fread(employee->supervisorName, sizeof(head->employeeName), 1, file);
			fread(&departmentValue, sizeof(departmentValue), 1, file);
			if(departmentValue == HR){
				employee->department = HR;
			}
			else if(departmentValue == Marketing){
				employee->department = Marketing;
			}
			else{
				employee->department = IT;
			}
			fread(&employee->idNumber, sizeof(head->idNumber), 1, file);
			fread(&employee->roomNumber, sizeof(head->roomNumber), 1, file);
			if(head == NULL){
				head = employee;
			}
			else{
				temp->next = employee;
			}
			employee->next = NULL;
			temp = employee;
		}
		fclose(file);
	}
	else{
		printf("%s not found\n", fileName);
	}
}

void save(char* fileName){
	EMP *temp, *employee;
	employee = head;
	FILE* file;
	int i = 0, departmentValue = 0;
	file = fopen(fileName, "wb");
	if(file != NULL){
		fwrite(&count, sizeof(count), 1, file);
		for(; i < count; i++){
			fwrite(employee->employeeName, sizeof(head->employeeName), 1, file);
			fwrite(employee->supervisorName, sizeof(head->employeeName), 1, file);
			fwrite(&departmentValue, sizeof(departmentValue), 1, file);
			if(departmentValue == HR){
				employee->department = HR;
			}
			else if(departmentValue == Marketing){
				employee->department = Marketing;
			}
			else{
				employee->department = IT;
			}
			fwrite(&employee->idNumber, sizeof(head->idNumber), 1, file);
			fwrite(&employee->roomNumber, sizeof(head->roomNumber), 1, file);
			employee = employee->next;
		}
		fclose(file);
	}
	else{
		printf("%s not found\n", fileName);
	}
}

int add(char* employeeName_input, char* supervisorName_input, char* department_input, unsigned int idNumber_input, unsigned int roomNumber_input){
	EMP* newNode = NULL;
	EMP* last = NULL;
	newNode = malloc(sizeof(EMP));
	strcpy(newNode->employeeName, employeeName_input);
	strcpy(newNode->supervisorName, supervisorName_input);
	if(strcmp(department_input, "HR") == 0){
		newNode->department = HR;
	}
	else if(strcmp(department_input, "Marketing") == 0){
		newNode->department = Marketing;
	}
	else{
		newNode->department = IT;
	}
	newNode->idNumber = idNumber_input;
	newNode->roomNumber = roomNumber_input;
	newNode->next = NULL;
	if(count == 0){
		head = newNode;
		count++;
		return 1;
	}
	last = head;
	while(last->next){
		if(strcmp(last->employeeName, employeeName_input) == 0 && last->idNumber == idNumber_input){
			return 0;
		}
		last = last->next;
	}
	last->next = newNode;
	count++;
	return 1;
}

int delete(unsigned int idNumber_input){
	EMP *previous, *current;
	previous = head;
	current = head->next;
	if(previous->idNumber == idNumber_input){
		head = head->next;
		count--;
		return 1;
	}
	for(int i = 0; i < count; i++){
		if(current->idNumber == idNumber_input){
			previous->next = current->next;
			count--;
			return 1;
		}
		current = current->next;
		previous = previous->next;
	}
	return 0;
}

void display(){
	EMP* iterator = malloc(sizeof(EMP));
	iterator = head;
	char* departmentString;
		for(int i = 0; i < count; i++){
			printf("\nEmployee name: %s", iterator->employeeName);				// display employee name
			printf("\nSupervisor name: %s", iterator->supervisorName);				// display supervisor name

			if (iterator->department == HR)						// find what to display for department
				departmentString = "HR";
			else if (iterator->department == Marketing)
				departmentString = "Marketing";
			else
				departmentString = "IT";
			printf("\nDepartment: %s", departmentString);			// display department
			printf("\nID Number: %d", iterator->idNumber);
			printf("\nRoom number: %d", iterator->roomNumber);				// display room number
			printf("\n");
			iterator = iterator->next;
		}
	free(iterator);
}

void swap(EMP* a, EMP* b){
	EMP* temp = malloc(sizeof(EMP));
	strcpy(temp->employeeName, a->employeeName);
	strcpy(temp->supervisorName, a->supervisorName);
	temp->department = a->department;
	temp->idNumber = a->idNumber;
	temp->roomNumber = a->roomNumber;

	strcpy(a->employeeName, b->employeeName);
	strcpy(a->supervisorName, b->supervisorName);
	a->department = b->department;
	a->idNumber = b->idNumber;
	a->roomNumber = b->roomNumber;

	strcpy(b->employeeName, temp->employeeName);
	strcpy(b->supervisorName, temp->supervisorName);
	b->department = temp->department;
	b->idNumber = temp->idNumber;
	b->roomNumber = temp->roomNumber;

	free(temp);
}

void sort(){ 
	EMP *start = head, *min, *iterator;
	if(count == 0){
		return;
	}
	else{
		while(start->next){
			min = start;
			iterator = start->next;
			while(iterator){
				if(min->idNumber > iterator->idNumber){
					min = iterator;
				}
				iterator = iterator->next;
			}
			swap(start, min);
			start = start->next;
		}
	}
}