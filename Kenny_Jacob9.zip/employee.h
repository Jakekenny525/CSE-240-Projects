#include <string>
using namespace std;

class Employee {
private:
	string name;
	int ID, roomNumber;
	string supervisorName;

public:
	Employee();		// constructor

	void setName(string name_input);
	void setID(int id_input);
	void setRoomNumber(int roomNumber_input);
	void setSupervisorName(string supervisorName_input);
	void displayEmployee();
	string getName();
	int getID();
	int getRoomNumber();
	string getSupervisorName();
};