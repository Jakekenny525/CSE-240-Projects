/*Facts*/

status(sam, freshman).
status(jack, sophomore).
topic(sam, bio).
topic(sam, eng).
topic(jack, mat).
topic(jack, cse).
class(sam, taxonomy).
class(sam, evolution).
class(sam, reading).
class(sam, writing).
class(jack, calculus).
class(jack, algebra).
class(jack, algorithms).
class(jack, databases).

/*Rules*/
info(X, Y) :-
    status(X,Y).

info(X, Y) :-
    topic(X, Y).

schedule(X, Y) :-
    class(X, Y).
